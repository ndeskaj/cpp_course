#include "DeadCell.h"
//TODO: task c)
DeadCell::DeadCell(double health_, double power_, double defence_)
// Your Code
{
  // Your Code
}

DeadCell::~DeadCell() {}
//TODO: task k)
Food *DeadCell::clone() const {
  // Your Code
  return 0;
}
